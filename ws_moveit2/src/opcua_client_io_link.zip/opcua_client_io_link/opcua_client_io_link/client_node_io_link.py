import rclpy
from rclpy.node import Node

from std_msgs.msg import Float
import restackcell_durchfluss

class MinimalPublisher(Node):

    def init(self):
        super().init('minimal_publisher')
        self.publisher_sensor1 = self.create_publisher(Float, 'Durchfluss_Sensor_Bemi_1', 10)   # Publisher Sensor 1
        self.publisher_sensor2 = self.create_publisher(Float, 'Durchfluss_Sensor_Bemi_2', 10)   # Publisher Sensor 2
        self.publisher_sensor3 = self.create_publisher(Float, 'Durchfluss_Sensor_Spindel', 10)  # Publisher Sensor 3
        self.timer_period = 0.1 # seconds
        self.timer = self.create_timer(self.timer_period, self.timer_callback)
        self.url = 'opc.tcp://192.168.13.179:4841'
        self.client = restackcell_durchfluss.connect_to_opcua_server(self.url)
        self.volume_sensor1 = 0.0
        self.volume_sensor2 = 0.0
        self.volume_sensor3 = 0.0

    def timer_callback(self):

        # Sensordaten auslesen     
        flow_rate_bemi_1 = restackcell_durchfluss.get_flow_rate_bemi_1(self.client)     #Variable von Sensorwert 1
        flow_rate_bemi_2 =  restackcell_durchfluss.get_flow_rate_bemi_2(self.client)    #Variable von Sensorwert 2
        flow_rate_spindle = restackcell_durchfluss.get_flow_rate_spindle(self.client)   #Variable von Sensorwert 3

        # Volumen berechnen
        volume_sensor1 += flow_rate_bemi_1 * self.timer / 60    # Differenzvolumen in Litern addieren
        volume_sensor2 += flow_rate_bemi_2 * self.timer / 60
        volume_sensor3 += flow_rate_spindle * self.timer / 60

        # Danach Sensordaten in msg packen
        Msg1 = Float()
        Msg2 = Float()
        Msg3 = Float()
        Msg1.data = flow_rate_bemi_1    # or integrated volume_sensor1
        Msg2.data = flow_rate_bemi_2    # or integrated volume_sensor2
        Msg3.data = flow_rate_spindle   # or integrated volume_sensor3

        # Sensordaten publishen
        self.publisher_sensor1.publish(Msg1)
        self.publisher_sensor2.publish(Msg2)
        self.publisher_sensor3.publish(Msg3)

        # Logoutput, dass Sensordaten gepublished wurden
        self.get_logger().info('Publishing: "%.3f"' % Msg1.data)
        self.get_logger().info('Publishing: "%.3f"' % Msg2.data)
        self.get_logger().info('Publishing: "%.3f"' % Msg3.data)


def main(args=None):
    rclpy.init(args=args)

    minimal_publisher = MinimalPublisher()

    rclpy.spin(minimal_publisher)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

